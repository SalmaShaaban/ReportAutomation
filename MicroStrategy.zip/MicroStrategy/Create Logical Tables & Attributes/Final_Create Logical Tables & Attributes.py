from mstrio.connection import Connection
from mstrio.users_and_groups.user import list_users
from mstrio.object_management.folder import Folder
from mstrio.object_management.folder import list_folders
import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
import os
import platform
import time
import subprocess
from pathlib import Path
from mstrio.connection import get_connection
from mstrio.datasources.database_connections import DatabaseConnections
from mstrio.datasources import DatasourceInstance
from mstrio.modeling.schema.table.logical_table import LogicalTable, list_logical_tables
from mstrio.modeling.schema.attribute import Attribute, AttributeForm , list_attributes
import pandas as pd
from mstrio.modeling.schema.helpers import (ObjectSubType, PhysicalTableType, SchemaObjectReference, TableColumn, TableColumnMergeOption)
from mstrio.modeling import DataType, SchemaManagement, SchemaUpdateType
from mstrio.modeling.expression import ( Expression, ExpressionFormat, Token, ColumnReference, Constant, Operator, FactExpression, Variant, VariantType, Function)
from mstrio.modeling.schema import (Attribute, AttributeDisplays, AttributeForm, AttributeSort, AttributeSorts, DataType, FormReference, list_attributes, ObjectSubType, Relationship, SchemaManagement, SchemaObjectReference, SchemaUpdateType)



def get_drive_path():
    """Find the D: drive or suitable alternative location."""
    # Try D: drive first
    if os.name == 'nt' and os.path.exists('D:\\'):
        return 'D:\\'
    # For non-Windows systems or if D: doesn't exist
    home = str(Path.home())
    
    # Try common alternative locations
    alternatives = [
        '/mnt/d/',  # Common Linux mount point for D:
        '/media/d/', # Another common Linux location
        '/Volumes/D/',  # macOS location
        home        # Fallback to user's home directory
    ]
    for alt in alternatives:
        if os.path.exists(alt):
            return alt
    return home  # Final fallback

def create_excel_with_headers(filename, headers, folder_names, folder_ids, ds_instance_names):
    try:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "SampleData"
        ws.append(headers)

        # Create hidden sheet for dropdown and lookup values
        ws_hidden_folders = wb.create_sheet(title="FolderDropdownData")
        for i, (name, fid) in enumerate(zip(folder_names, folder_ids), start=1):
            ws_hidden_folders.cell(row=i, column=1, value=name)
            ws_hidden_folders.cell(row=i, column=2, value=fid)

        ws_hidden_ds = wb.create_sheet(title="DatasourceDropdownData")
        for i, name in enumerate(ds_instance_names, start=1):
            ws_hidden_ds.cell(row=i, column=1, value=name)

        # Hide dropdown sheets
        ws_hidden_folders.sheet_state = 'hidden'
        ws_hidden_ds.sheet_state = 'hidden'

        # Folder name dropdown (Column E)
        dv_folder = DataValidation(
            type="list",
            formula1=f"=FolderDropdownData!$A$1:$A${len(folder_names)}",
            allow_blank=False,
            showErrorMessage=True,
            errorTitle="Invalid Input",
            error="Please select a Folder Destination Name from the dropdown list only."
        )
        ws.add_data_validation(dv_folder)
        dv_folder.add('E2:E100')

        # Datasource instance dropdown (Column D)
        dv_ds = DataValidation(
            type="list",
            formula1=f"=DatasourceDropdownData!$A$1:$A${len(ds_instance_names)}",
            allow_blank=False,
            showErrorMessage=True,
            errorTitle="Invalid Input",
            error="Please select a Datasource Instance from the dropdown list only."
        )
        ws.add_data_validation(dv_ds)
        dv_ds.add('D2:D100')

        # Apply VLOOKUP formula to Column F to match Folder Name in E with its ID
        for row in range(2, 101):  # Rows 2 to 100
            formula = f'=IFERROR(VLOOKUP(E{row}, FolderDropdownData!A:B, 2, FALSE), "")'
            ws.cell(row=row, column=6).value = formula  # Column F is index 6

        wb.save(filename)
        return True
    except Exception as e:
        print(f"Error creating Excel file: {e}")
        return False


def open_file_for_editing(filename):
    system = platform.system()
    try:
        if system == 'Darwin':
            subprocess.run(['open', filename])
        elif system == 'Windows':
            os.startfile(filename)
        else:
            subprocess.run(['xdg-open', filename])
    except Exception as e:
        print(f"Error opening file: {e}")

def wait_for_file_save_and_unlock(filename):
    initial_mod_time = os.path.getmtime(filename)

    while True:
        time.sleep(2)
        current_mod_time = os.path.getmtime(filename)

        try:
            with open(filename, 'rb'):
                pass
        except PermissionError:
            continue

        if current_mod_time != initial_mod_time:
            return


# 3. Function to run SQL and fetch columns
def get_columns_from_query(sql_query, db_instance, project_id):
    query_result = db_instance.execute_query(query=sql_query, project_id=project_id, retry_delay=60)
    df = pd.DataFrame(query_result)
    if df.empty:
        raise ValueError("Query returned no data.")
    df_results = pd.DataFrame(df['results'].iloc[0])
    return df_results

# 4. Map pandas types to MicroStrategy types
def map_pd_dtype_to_mstr_datatype(dtype):
    print(dtype)
    if pd.api.types.is_integer_dtype(dtype):
        return DataType.Type.INTEGER, "0", "10"
    elif pd.api.types.is_float_dtype(dtype):
        return DataType.Type.FLOAT, "15", "38"
    elif pd.api.types.is_datetime64_any_dtype(dtype):
        return DataType.Type.DATE_TIME, "0", "0"
    else:
        return DataType.Type.N_VAR_CHAR, "0", "255"

# 4.1 Find Logical Table by name
def find_logical_table_by_name(logical_table_name,conn):
    tables = list_logical_tables(connection=conn)
    for tbl in tables:
        if tbl.name == logical_table_name:
            return tbl
    return None

# 5. Create or Get Logical Table
def create_or_get_logical_table(sql_query, df, logical_table_name, logical_table_description,conn,DATASOURCE_ID):
    existing_table = find_logical_table_by_name(logical_table_name,conn)
    if existing_table:
        print(f"? Logical Table '{logical_table_name}' already exists. Using existing table (ID: {existing_table.id}).")
        logical_table = LogicalTable(connection=conn, id=existing_table.id)
        return logical_table  # ?? ADD THIS !!
    else:
        print(f"?? Logical Table '{logical_table_name}' does not exist. Creating it...")    
        columns = []
        for col in df.columns:
            dtype, scale, precision = map_pd_dtype_to_mstr_datatype(df[col])
            table_col = TableColumn(
                data_type=DataType(
                    type=dtype,
                    scale=scale,
                    precision=precision
                ),
                column_name=col
            )
            columns.append(table_col)
        logical_table = LogicalTable.create(
            connection=conn,
            physical_table_type=PhysicalTableType.SQL,
            columns=columns,
            sql_statement=sql_query,
            primary_data_source=SchemaObjectReference(
                object_id=DATASOURCE_ID,
                sub_type=ObjectSubType.DB_ROLE
            ),
            table_name=logical_table_name,
            table_description=logical_table_description
        )
        return logical_table

# 5.1 Find Attributes by name
def find_attribute_by_name(attribute,conn):
    attributes = list_attributes(connection=conn)
    for atr in attributes:
        if atr.name == attribute:
            return atr
    return None

# 6. Create Attributes
def create_attributes_from_logical_table(df, logical_table, folder_id,conn,):
    attributes = []
    columns = logical_table.list_columns()
    for col in df.columns:
        # Find the column object in the Logical Table
        logical_col = next((c for c in columns if c.column_name.upper() == col.upper()), None)
        if not logical_col:
            print(f"?? Column {col} not found in Logical Table.")
            continue
        # Create Attribute
        existing_attribute = find_attribute_by_name(col,conn)
        print(col)
        if existing_attribute:
            print(f"? Attribute '{logical_col.name}' already exists. With (ID: {existing_attribute.id}).")
            continue
        else:
            attr = Attribute.create(
                connection=conn,
                name=col,
                sub_type=ObjectSubType.ATTRIBUTE,
                destination_folder=folder_id,
                forms=[
                    AttributeForm.local_create(
                        conn,
                        name=col,
                        alias=col,
                        category='None',
                        display_format=AttributeForm.DisplayFormat.TEXT,  # You can enhance later based on type
                        data_type=logical_col.data_type,
                        expressions=[
                            FactExpression(
                                expression=Expression(
                                    tree=ColumnReference(
                                        column_name=col,
                                        object_id=logical_col.id
                                    ),
                                ),
                                tables=[
                                    SchemaObjectReference(
                                        name=logical_table.name,
                                        sub_type=ObjectSubType.LOGICAL_TABLE,
                                        object_id=logical_table.id
                                    )
                                ]
                            )
                        ],
                        lookup_table=SchemaObjectReference(
                            name=logical_table.name,
                            sub_type=ObjectSubType.LOGICAL_TABLE,
                            object_id=logical_table.id
                        ),
                    ),
                ],
                key_form=FormReference(name=col),
                displays=AttributeDisplays(
                    report_displays=[FormReference(name=col)],
                    browse_displays=[FormReference(name=col)],
                ),
                attribute_lookup_table=SchemaObjectReference(
                    name=logical_table.name,
                    sub_type=ObjectSubType.LOGICAL_TABLE,
                    object_id=logical_table.id
                ),
                hidden=False,
            )
            print(f"? Attribute '{attr.name}' created.")
            attributes.append(attr)
    return attributes

# 7. Main
def main():

    # 1. Connect to MicroStrategy
    conn = get_connection(workstationData, project_name='BDC - General Reports')
    ds_instances = DatasourceInstance._list_datasource_instances(connection=conn, to_dictionary=True, database_types=['oracle'])
    # Extract just the names
    ds_instance_names = [ds['name'] for ds in ds_instances]
    folder_id = "D3C7D461F69C4610AA6BAA5EF51F4125"  
    folder_content = Folder(conn, id=folder_id).get_contents(type=8)  # type 3 = Report
    folder_names = [folder.name for folder in folder_content]
    folder_ids = [folder.id for folder in folder_content]
    # Define your headers
    headers = ['REPORT_NAME','QUERY_WITHOUT_PROMPTS', 'QUERY_WITH_PROMPTS','DATA_SOURCE_NAME','DESTINATION_FOLDER_NAME','DESTINATION_FOLDER_ID']
    # Get the appropriate drive/path
    base_path = get_drive_path()
    # Create a data directory if it doesn't exist
    data_dir = os.path.join(base_path, '_MicroStrategy - Query Prompt')
    os.makedirs(data_dir, exist_ok=True)
    excel_file_name = os.path.join(data_dir, 'MicroStrategy_File_Input.xlsx')
    if create_excel_with_headers(excel_file_name, headers,folder_names,folder_ids,ds_instance_names):
        open_file_for_editing(excel_file_name)
        wait_for_file_save_and_unlock(excel_file_name)

        time.sleep(1)
        df = pd.read_excel(excel_file_name, engine='openpyxl')
        print(df)
    project_id = conn.project_id
    output_file = pd.read_excel(excel_file_name)
    print(output_file.head())
    for i, row in output_file.iterrows():
        logical_table_name = row['REPORT_NAME'].upper()
        sql = row['QUERY_WITHOUT_PROMPTS'].upper()
        sql_query = f"SELECT * FROM ({sql}) FETCH FIRST 1 ROWS ONLY;"
        print(sql_query)
        user_name= conn.user_full_name
        db_instance_name= row['DATA_SOURCE_NAME']
        db_instance = DatasourceInstance(connection=conn, name=db_instance_name)
        DATASOURCE_ID = db_instance.id  # You will need this for primary_data_source
        print(DATASOURCE_ID)
        # Fetch columns
        df = get_columns_from_query(sql_query, db_instance, project_id)
        print(df.head())
        print("? Columns fetched from database.")
        # Create Logical Table
        logical_table_description = ' '
        folder_id = '6F55FB47F9974EABA18CB0C5FF46785C'
        logical_table =  create_or_get_logical_table(sql_query, df, logical_table_name, logical_table_description,conn,DATASOURCE_ID)
        print(f"? Logical Table '{logical_table.name}' created.")
        # Create Attributes
        create_attributes_from_logical_table(df, logical_table, folder_id,conn)
        print("? Attributes created successfully.")
        schema_manager = SchemaManagement(connection=conn)
        task = schema_manager.reload(update_types=[SchemaUpdateType.LOGICAL_SIZE])
        chunk_size = 4000
        query_chunks = [sql_query[i:i+chunk_size] for i in range(0, len(sql_query), chunk_size)]
        # Build the TO_CLOB parts
        to_clob_parts = " ||\n    ".join([f"TO_CLOB(q'[{chunk}]')" for chunk in query_chunks])
        # Create the final SQL statement
        db_instance_log = DatasourceInstance(connection=conn, name='STG')
        Query = f"""INSERT INTO MSTR_REPORTS_LOG (LOG_ID, LOGICAL_TABLE_NAME, QUERY, USERNAME, DATETIME) VALUES(NULL, '{logical_table_name}', {to_clob_parts}, '{user_name}', NULL);"""
        #print(Query)
        db_instance_log.execute_query(query=Query, project_id=project_id)
        print("Done")
if __name__ == "__main__":
    main()