from mstrio.connection import Connection
from mstrio.users_and_groups.user import list_users
from mstrio.object_management.folder import Folder
from mstrio.object_management.folder import list_folders
import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
import os
import platform
import time
import subprocess
from pathlib import Path
from mstrio.connection import get_connection
from mstrio.datasources.database_connections import DatabaseConnections
from mstrio.datasources import DatasourceInstance
from mstrio.modeling.schema.table.logical_table import LogicalTable, list_logical_tables
from mstrio.modeling.schema.attribute import Attribute, AttributeForm, list_attributes
import pandas as pd
from mstrio.modeling.schema.helpers import (ObjectSubType, PhysicalTableType, SchemaObjectReference, TableColumn, TableColumnMergeOption)
from mstrio.modeling import DataType, SchemaManagement, SchemaUpdateType
from mstrio.modeling.expression import (Expression, ExpressionFormat, Token, ColumnReference, Constant, Operator, FactExpression, Variant, VariantType, Function)
from mstrio.modeling.schema import (Attribute, AttributeDisplays, AttributeForm, AttributeSort, AttributeSorts, DataType, FormReference, list_attributes, ObjectSubType, Relationship, SchemaManagement, SchemaObjectReference, SchemaUpdateType)
import logging
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
import json
from typing import List, Dict, Tuple, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('mstr_automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Constants
BATCH_SIZE = 10
MAX_RETRIES = 3
RETRY_DELAY = 60
EXCEL_ROW_LIMIT = 100

class MicroStrategyAutomation:
    def __init__(self, project_name: str):
        self.conn = None
        self.project_name = project_name
        self.cache = {}
        self.initialize_connection()

    def initialize_connection(self):
        """Initialize MicroStrategy connection with retry logic"""
        for attempt in range(MAX_RETRIES):
            try:
                self.conn = get_connection(workstationData, project_name=self.project_name)
                logger.info(f"Successfully connected to {self.project_name}")
                return
            except Exception as e:
                if attempt == MAX_RETRIES - 1:
                    logger.error(f"Failed to connect after {MAX_RETRIES} attempts: {str(e)}")
                    raise
                logger.warning(f"Connection attempt {attempt + 1} failed: {str(e)}")
                time.sleep(RETRY_DELAY)

    @lru_cache(maxsize=128)
    def get_datasource_instances(self) -> List[str]:
        """Get cached list of datasource instances"""
        try:
            ds_instances = DatasourceInstance._list_datasource_instances(
                connection=self.conn, 
                to_dictionary=True, 
                database_types=['oracle']
            )
            return [ds['name'] for ds in ds_instances]
        except Exception as e:
            logger.error(f"Error fetching datasource instances: {str(e)}")
            raise

    @lru_cache(maxsize=128)
    def get_folder_content(self, folder_id: str) -> Tuple[List[str], List[str]]:
        """Get cached folder content"""
        try:
            folder_content = Folder(self.conn, id=folder_id).get_contents(type=8)
            return (
                [folder.name for folder in folder_content],
                [folder.id for folder in folder_content]
            )
        except Exception as e:
            logger.error(f"Error fetching folder content: {str(e)}")
            raise

    def create_excel_with_headers(self, filename: str, headers: List[str], folder_names: List[str], 
                                folder_ids: List[str], ds_instance_names: List[str]) -> bool:
        """Create Excel file with optimized data validation and formulas"""
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "SampleData"
            ws.append(headers)

            # Create and populate hidden sheets
            self._create_hidden_sheets(wb, folder_names, folder_ids, ds_instance_names)
            
            # Add data validations
            self._add_data_validations(ws, len(folder_names), len(ds_instance_names))
            
            # Add VLOOKUP formulas
            self._add_vlookup_formulas(ws)

            wb.save(filename)
            logger.info(f"Excel file created successfully: {filename}")
            return True
        except Exception as e:
            logger.error(f"Error creating Excel file: {str(e)}")
            return False

    def _create_hidden_sheets(self, wb: openpyxl.Workbook, folder_names: List[str], 
                            folder_ids: List[str], ds_instance_names: List[str]):
        """Create and populate hidden sheets for dropdown data"""
        # Folder data sheet
        ws_folders = wb.create_sheet(title="FolderDropdownData")
        for i, (name, fid) in enumerate(zip(folder_names, folder_ids), start=1):
            ws_folders.cell(row=i, column=1, value=name)
            ws_folders.cell(row=i, column=2, value=fid)
        ws_folders.sheet_state = 'hidden'

        # Datasource data sheet
        ws_ds = wb.create_sheet(title="DatasourceDropdownData")
        for i, name in enumerate(ds_instance_names, start=1):
            ws_ds.cell(row=i, column=1, value=name)
        ws_ds.sheet_state = 'hidden'

    def _add_data_validations(self, ws: openpyxl.Worksheet, folder_count: int, ds_count: int):
        """Add data validations to the worksheet"""
        # Folder validation
        dv_folder = DataValidation(
            type="list",
            formula1=f"=FolderDropdownData!$A$1:$A${folder_count}",
            allow_blank=False,
            showErrorMessage=True,
            errorTitle="Invalid Input",
            error="Please select a Folder Destination Name from the dropdown list only."
        )
        ws.add_data_validation(dv_folder)
        dv_folder.add('E2:E100')

        # Datasource validation
        dv_ds = DataValidation(
            type="list",
            formula1=f"=DatasourceDropdownData!$A$1:$A${ds_count}",
            allow_blank=False,
            showErrorMessage=True,
            errorTitle="Invalid Input",
            error="Please select a Datasource Instance from the dropdown list only."
        )
        ws.add_data_validation(dv_ds)
        dv_ds.add('D2:D100')

    def _add_vlookup_formulas(self, ws: openpyxl.Worksheet):
        """Add VLOOKUP formulas to the worksheet"""
        for row in range(2, EXCEL_ROW_LIMIT + 1):
            formula = f'=IFERROR(VLOOKUP(E{row}, FolderDropdownData!A:B, 2, FALSE), "")'
            ws.cell(row=row, column=6).value = formula

    def process_batch(self, batch: pd.DataFrame) -> None:
        """Process a batch of rows with error handling"""
        for _, row in batch.iterrows():
            try:
                self._process_single_row(row)
            except Exception as e:
                logger.error(f"Error processing row {row['REPORT_NAME']}: {str(e)}")
                continue

    def _process_single_row(self, row: pd.Series) -> None:
        """Process a single row with all necessary operations"""
        logical_table_name = row['REPORT_NAME'].upper()
        sql = row['QUERY_WITHOUT_PROMPTS'].upper()
        sql_query = f"SELECT * FROM ({sql}) FETCH FIRST 1 ROWS ONLY;"
        
        # Get database instance
        db_instance = DatasourceInstance(connection=self.conn, name=row['DATA_SOURCE_NAME'])
        
        # Fetch columns and create logical table
        df = self.get_columns_from_query(sql_query, db_instance)
        logical_table = self.create_or_get_logical_table(sql_query, df, logical_table_name, ' ', db_instance.id)
        
        # Create attributes
        self.create_attributes_from_logical_table(df, logical_table, row['DESTINATION_FOLDER_ID'])
        
        # Log the operation
        self._log_operation(logical_table_name, sql_query, self.conn.user_full_name)

    def get_columns_from_query(self, sql_query: str, db_instance: DatasourceInstance) -> pd.DataFrame:
        """Execute query and get columns with retry logic"""
        for attempt in range(MAX_RETRIES):
            try:
                query_result = db_instance.execute_query(
                    query=sql_query, 
                    project_id=self.conn.project_id, 
                    retry_delay=RETRY_DELAY
                )
                df = pd.DataFrame(query_result)
                if df.empty:
                    raise ValueError("Query returned no data.")
                return pd.DataFrame(df['results'].iloc[0])
            except Exception as e:
                if attempt == MAX_RETRIES - 1:
                    logger.error(f"Failed to execute query after {MAX_RETRIES} attempts: {str(e)}")
                    raise
                logger.warning(f"Query attempt {attempt + 1} failed: {str(e)}")
                time.sleep(RETRY_DELAY)

    def _log_operation(self, logical_table_name: str, sql_query: str, username: str) -> None:
        """Log operation to database with chunked query"""
        try:
            chunk_size = 4000
            query_chunks = [sql_query[i:i+chunk_size] for i in range(0, len(sql_query), chunk_size)]
            to_clob_parts = " ||\n    ".join([f"TO_CLOB(q'[{chunk}]')" for chunk in query_chunks])
            
            db_instance_log = DatasourceInstance(connection=self.conn, name='STG')
            query = f"""INSERT INTO MSTR_REPORTS_LOG (LOG_ID, LOGICAL_TABLE_NAME, QUERY, USERNAME, DATETIME) 
                       VALUES(NULL, '{logical_table_name}', {to_clob_parts}, '{username}', NULL);"""
            
            db_instance_log.execute_query(query=query, project_id=self.conn.project_id)
            logger.info(f"Successfully logged operation for {logical_table_name}")
        except Exception as e:
            logger.error(f"Error logging operation: {str(e)}")

def get_drive_path():
    """Find the D: drive or suitable alternative location."""
    # Try D: drive first
    if os.name == 'nt' and os.path.exists('D:\\'):
        return 'D:\\'
    # For non-Windows systems or if D: doesn't exist
    home = str(Path.home())
    
    # Try common alternative locations
    alternatives = [
        '/mnt/d/',  # Common Linux mount point for D:
        '/media/d/', # Another common Linux location
        '/Volumes/D/',  # macOS location
        home        # Fallback to user's home directory
    ]
    for alt in alternatives:
        if os.path.exists(alt):
            return alt
    return home  # Final fallback

def create_excel_with_headers(filename, headers, folder_names, folder_ids, ds_instance_names):
    try:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "SampleData"
        ws.append(headers)

        # Create hidden sheet for dropdown and lookup values
        ws_hidden_folders = wb.create_sheet(title="FolderDropdownData")
        for i, (name, fid) in enumerate(zip(folder_names, folder_ids), start=1):
            ws_hidden_folders.cell(row=i, column=1, value=name)
            ws_hidden_folders.cell(row=i, column=2, value=fid)

        ws_hidden_ds = wb.create_sheet(title="DatasourceDropdownData")
        for i, name in enumerate(ds_instance_names, start=1):
            ws_hidden_ds.cell(row=i, column=1, value=name)

        # Hide dropdown sheets
        ws_hidden_folders.sheet_state = 'hidden'
        ws_hidden_ds.sheet_state = 'hidden'

        # Folder name dropdown (Column E)
        dv_folder = DataValidation(
            type="list",
            formula1=f"=FolderDropdownData!$A$1:$A${len(folder_names)}",
            allow_blank=False,
            showErrorMessage=True,
            errorTitle="Invalid Input",
            error="Please select a Folder Destination Name from the dropdown list only."
        )
        ws.add_data_validation(dv_folder)
        dv_folder.add('E2:E100')

        # Datasource instance dropdown (Column D)
        dv_ds = DataValidation(
            type="list",
            formula1=f"=DatasourceDropdownData!$A$1:$A${len(ds_instance_names)}",
            allow_blank=False,
            showErrorMessage=True,
            errorTitle="Invalid Input",
            error="Please select a Datasource Instance from the dropdown list only."
        )
        ws.add_data_validation(dv_ds)
        dv_ds.add('D2:D100')

        # Apply VLOOKUP formula to Column F to match Folder Name in E with its ID
        for row in range(2, 101):  # Rows 2 to 100
            formula = f'=IFERROR(VLOOKUP(E{row}, FolderDropdownData!A:B, 2, FALSE), "")'
            ws.cell(row=row, column=6).value = formula  # Column F is index 6

        wb.save(filename)
        return True
    except Exception as e:
        print(f"Error creating Excel file: {e}")
        return False


def open_file_for_editing(filename):
    system = platform.system()
    try:
        if system == 'Darwin':
            subprocess.run(['open', filename])
        elif system == 'Windows':
            os.startfile(filename)
        else:
            subprocess.run(['xdg-open', filename])
    except Exception as e:
        print(f"Error opening file: {e}")

def wait_for_file_save_and_unlock(filename):
    initial_mod_time = os.path.getmtime(filename)

    while True:
        time.sleep(2)
        current_mod_time = os.path.getmtime(filename)

        try:
            with open(filename, 'rb'):
                pass
        except PermissionError:
            continue

        if current_mod_time != initial_mod_time:
            return


# 3. Function to run SQL and fetch columns
def get_columns_from_query(sql_query, db_instance, project_id):
    query_result = db_instance.execute_query(query=sql_query, project_id=project_id, retry_delay=60)
    df = pd.DataFrame(query_result)
    if df.empty:
        raise ValueError("Query returned no data.")
    df_results = pd.DataFrame(df['results'].iloc[0])
    return df_results

# 4. Map pandas types to MicroStrategy types
def map_pd_dtype_to_mstr_datatype(dtype):
    print(dtype)
    if pd.api.types.is_integer_dtype(dtype):
        return DataType.Type.INTEGER, "0", "10"
    elif pd.api.types.is_float_dtype(dtype):
        return DataType.Type.FLOAT, "15", "38"
    elif pd.api.types.is_datetime64_any_dtype(dtype):
        return DataType.Type.DATE_TIME, "0", "0"
    else:
        return DataType.Type.N_VAR_CHAR, "0", "255"

# 4.1 Find Logical Table by name
def find_logical_table_by_name(logical_table_name,conn):
    tables = list_logical_tables(connection=conn)
    for tbl in tables:
        if tbl.name == logical_table_name:
            return tbl
    return None

# 5. Create or Get Logical Table
def create_or_get_logical_table(sql_query, df, logical_table_name, logical_table_description,conn,DATASOURCE_ID):
    existing_table = find_logical_table_by_name(logical_table_name,conn)
    if existing_table:
        print(f"? Logical Table '{logical_table_name}' already exists. Using existing table (ID: {existing_table.id}).")
        logical_table = LogicalTable(connection=conn, id=existing_table.id)
        return logical_table  # ?? ADD THIS !!
    else:
        print(f"?? Logical Table '{logical_table_name}' does not exist. Creating it...")    
        columns = []
        for col in df.columns:
            dtype, scale, precision = map_pd_dtype_to_mstr_datatype(df[col])
            table_col = TableColumn(
                data_type=DataType(
                    type=dtype,
                    scale=scale,
                    precision=precision
                ),
                column_name=col
            )
            columns.append(table_col)
        logical_table = LogicalTable.create(
            connection=conn,
            physical_table_type=PhysicalTableType.SQL,
            columns=columns,
            sql_statement=sql_query,
            primary_data_source=SchemaObjectReference(
                object_id=DATASOURCE_ID,
                sub_type=ObjectSubType.DB_ROLE
            ),
            table_name=logical_table_name,
            table_description=logical_table_description
        )
        return logical_table

# 5.1 Find Attributes by name
def find_attribute_by_name(attribute,conn):
    attributes = list_attributes(connection=conn)
    for atr in attributes:
        if atr.name == attribute:
            return atr
    return None

# 6. Create Attributes
def create_attributes_from_logical_table(df, logical_table, folder_id,conn,):
    attributes = []
    columns = logical_table.list_columns()
    for col in df.columns:
        # Find the column object in the Logical Table
        logical_col = next((c for c in columns if c.column_name.upper() == col.upper()), None)
        if not logical_col:
            print(f"?? Column {col} not found in Logical Table.")
            continue
        # Create Attribute
        existing_attribute = find_attribute_by_name(col,conn)
        print(col)
        if existing_attribute:
            print(f"? Attribute '{logical_col.name}' already exists. With (ID: {existing_attribute.id}).")
            continue
        else:
            attr = Attribute.create(
                connection=conn,
                name=col,
                sub_type=ObjectSubType.ATTRIBUTE,
                destination_folder=folder_id,
                forms=[
                    AttributeForm.local_create(
                        conn,
                        name=col,
                        alias=col,
                        category='None',
                        display_format=AttributeForm.DisplayFormat.TEXT,  # You can enhance later based on type
                        data_type=logical_col.data_type,
                        expressions=[
                            FactExpression(
                                expression=Expression(
                                    tree=ColumnReference(
                                        column_name=col,
                                        object_id=logical_col.id
                                    ),
                                ),
                                tables=[
                                    SchemaObjectReference(
                                        name=logical_table.name,
                                        sub_type=ObjectSubType.LOGICAL_TABLE,
                                        object_id=logical_table.id
                                    )
                                ]
                            )
                        ],
                        lookup_table=SchemaObjectReference(
                            name=logical_table.name,
                            sub_type=ObjectSubType.LOGICAL_TABLE,
                            object_id=logical_table.id
                        ),
                    ),
                ],
                key_form=FormReference(name=col),
                displays=AttributeDisplays(
                    report_displays=[FormReference(name=col)],
                    browse_displays=[FormReference(name=col)],
                ),
                attribute_lookup_table=SchemaObjectReference(
                    name=logical_table.name,
                    sub_type=ObjectSubType.LOGICAL_TABLE,
                    object_id=logical_table.id
                ),
                hidden=False,
            )
            print(f"? Attribute '{attr.name}' created.")
            attributes.append(attr)
    return attributes

# 7. Main
def main():
    try:
        # Initialize automation
        mstr = MicroStrategyAutomation('BDC - General Reports')
        
        # Get folder content
        folder_id = "D3C7D461F69C4610AA6BAA5EF51F4125"
        folder_names, folder_ids = mstr.get_folder_content(folder_id)
        
        # Get datasource instances
        ds_instance_names = mstr.get_datasource_instances()
        
        # Create Excel file
        headers = ['REPORT_NAME', 'QUERY_WITHOUT_PROMPTS', 'QUERY_WITH_PROMPTS',
                  'DATA_SOURCE_NAME', 'DESTINATION_FOLDER_NAME', 'DESTINATION_FOLDER_ID']
        
        base_path = get_drive_path()
        data_dir = os.path.join(base_path, '_MicroStrategy - Query Prompt')
        os.makedirs(data_dir, exist_ok=True)
        excel_file_name = os.path.join(data_dir, 'MicroStrategy_File_Input.xlsx')
        
        if mstr.create_excel_with_headers(excel_file_name, headers, folder_names, folder_ids, ds_instance_names):
            open_file_for_editing(excel_file_name)
            wait_for_file_save_and_unlock(excel_file_name)
            
            # Read and process Excel file in batches
            df = pd.read_excel(excel_file_name, engine='openpyxl')
            batches = [df[i:i + BATCH_SIZE] for i in range(0, len(df), BATCH_SIZE)]
            
            # Process batches using ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=min(len(batches), 4)) as executor:
                executor.map(mstr.process_batch, batches)
            
            logger.info("All batches processed successfully")
            
    except Exception as e:
        logger.error(f"Main execution failed: {str(e)}")
        raise

if __name__ == "__main__":
    main()