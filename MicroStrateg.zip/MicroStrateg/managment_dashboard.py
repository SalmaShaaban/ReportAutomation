import pandas as pd

df = pd.read_excel('tickets.xlsx')

df = df[~df['ID'].str.startswith('C')]

df['Ticket_Type'] = df['ID'].str[:2]

dashboard_data = df.groupby(['Assigned', 'Ticket_Type', 'Status', 'Module']).size().reset_index(name='Total_Tickets')

df['Ticket_Age'] = (pd.to_datetime('today') - pd.to_datetime(df['Open Time'])).dt.days

avg_ticket_age = df.groupby('Assigned')['Ticket_Age'].mean().reset_index(name='Avg_Ticket_Age')

dashboard_data = dashboard_data.merge(avg_ticket_age, on='Assigned', how='left')

status_columns = ['Pending Customer', 'In Progress', 'Open', 'Under Development']
status_pivot = dashboard_data.pivot_table(index=['Assigned', 'Ticket_Type', 'Module'], columns='Status', values='Total_Tickets', aggfunc='sum', fill_value=0)

status_pivot.columns = [col for col in status_pivot.columns]
status_pivot = status_pivot.reset_index()

status_pivot.to_excel('management_dashboard.xlsx', index=False)
print("Management Dashboard saved successfully!")
