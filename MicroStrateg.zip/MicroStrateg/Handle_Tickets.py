import pandas as pd

input_file = "tickets.xlsx"
output_file = "processed_tickets.xlsx"

data = pd.read_excel(input_file)

columns_to_keep = ["ID", "Status", "Assigned"]
data = data[columns_to_keep]

data = data[~data["ID"].str.startswith("C")]

data["Ticket Type"] = data["ID"].str[:2]

summary = (
    data.groupby(["Assigned", "Ticket Type", "Status"])["ID"]
    .count()
    .reset_index()
    .pivot(index=["Assigned", "Ticket Type"], columns="Status", values="ID")
    .fillna(0)
    .reset_index()
)

summary["Total Tickets"] = summary.iloc[:, 3:].sum(axis=1)

rf_im_totals = (
    data.groupby(["Assigned", "Ticket Type"])["ID"]
    .count()
    .reset_index()
    .pivot(index="Assigned", columns="Ticket Type", values="ID")
    .fillna(0)
    .reset_index()
)

rf_im_totals.columns = ["Assigned"] + [f"Total {col} Tickets" for col in rf_im_totals.columns[1:]]

final_summary = pd.merge(summary, rf_im_totals, on="Assigned", how="left")

final_summary.to_excel(output_file, index=False)

print(f"Processed ticket data with totals has been saved to '{output_file}'.")
