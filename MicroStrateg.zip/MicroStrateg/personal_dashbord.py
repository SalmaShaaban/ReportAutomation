import pandas as pd

df = pd.read_excel('tickets.xlsx')

df = df[~df['ID'].str.startswith('C')]

df['Ticket_Type'] = df['ID'].str[:2]

df['Ticket_Age'] = (pd.to_datetime('today') - pd.to_datetime(df['Open Time'])).dt.days

personal_dashboard = df[['ID', 'Ticket_Type', 'Status', 'Open Time', 'Module', 'Assigned', 'Ticket_Age']]

personal_dashboard = personal_dashboard.sort_values(by='Ticket_Age', ascending=False)

personal_dashboard.to_excel('personal_dashboard.xlsx', index=False)

print("Personal Dashboard saved successfully!")
